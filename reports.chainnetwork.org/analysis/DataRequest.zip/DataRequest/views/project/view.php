<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\models\Lookup;
use app\models\User;
use app\utilities\DataHelper;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\Project */

$this->title = $model->project_name;
$this->params['breadcrumbs'][] = ['label' => 'Projects', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="project-view">
    <p>
    <?php
          $dh = new DataHelper();
            $url = Url::to(['update', 'id'=>$model->id]);
           echo $dh->getModalButton($model, "update", "Edit Project", 'btn btn-primary pull-right btn-project','Edit Request',$url);
        ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'project_name',
            'project_aims:html',
            [                      
                'label' => 'Request Type',
                'value' => Lookup::getValue("RequestType", $model->request_type),
            ],
            
            [                      
                'label' => 'Type of Data',
                'value' => Lookup::getValue("TypeData", $model->type_data),
            ],
            [                      
                'label' => 'Type of Proposal',
                'value' => Lookup::getValue("ProposalType", $model->proposal_type),
            ],
            'date_submitted',
            'date_review',
            [                      
                'label' => 'IRB or Other Approvals',
                'value' => Lookup::getValue("IrbApproval", $model->irb_other_approval),
            ],
            'sap:html',
            'pub_plan:html',
            'target_completion_date',
            'milestones:html',
            [                      
                'label' => 'Responsible User',
                'value' => User::getUserNames($model->user_id)
            ],
            [                      
                'label' => 'Request Status',
                'value' => Lookup::getValue("RequestStatus", $model->request_status),
            ],
            'request_approved_by',
            'request_reviewed_by',
        ],
    ]) ?>

</div>
