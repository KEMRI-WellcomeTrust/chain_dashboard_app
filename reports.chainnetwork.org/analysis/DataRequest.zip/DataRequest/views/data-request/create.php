<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\DataRequest */

?>
<div class="data-request-create">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
