<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\data\ActiveDataProvider;
use app\models\DataRequestSearch;
use app\models\DataRequest;
use app\utilities\DataHelper;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel app\models\DataRequestSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="data-request-index">

<h1><?= Html::encode($this->title) ?></h1>
    <?php
        $searchModel = new DataRequestSearch();
        $query = DataRequest::find()->where(['project_id'=>$project_id]);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);
    
    Pjax::begin(['id'=>"pjax-data-request"]); ?>

    <p>
       <?php
          $dh = new DataHelper();
            $url = Url::to(['data-request/create', 'project_id'=>$project_id]);
           echo $dh->getModalButton(new \app\models\DataRequest(), "data-request/create", "DataRequest", 'btn btn-primary pull-right btn-project-user','Add a Data Request',$url);
           ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
                'label'=>'Primary Contact',
                'format'=>'raw',
                 'attribute'=>'user_id',
                 'filter' => app\models\User::getUserFilters(),
                 'value'=> function ($data){
                     return app\models\User::getUserNames($data->user_id);
                 }
             ],
            'data_crfs:ntext',
            'data_variables:ntext',
            'data_sites',
           [
                'label'=>'Status',
                'format'=>'raw',
                 'attribute'=>'status',
                 'filter' => app\models\Lookup::getLookupValues("DataStatus"),
                 'value'=> function ($data){
                     return app\models\Lookup::getValue("DataStatus", $data->status);
                 }
             ],
            //'date_from',
            //'date_to',
            //'other_info:ntext',
            //'received_date',
            //'reviewed_by',
            //'approved_by',
            //'approved_date',
            //'status_comments:ntext',
            //'feedback:ntext',

             ['class' => 'yii\grid\ActionColumn',
                'template' => '{update}{delete}',
                'buttons' => [

                            'update' => function ($url, $model) {
                               
                                $dh = new DataHelper();
                                $url = Url::to(['data-request/update','id'=>$model->id],true);
                                $link  = $dh->getModalButton($model, "data-request/update", "Project", 'glyphicon glyphicon-edit','',$url);
                                return "&nbsp;".$link;
                            },
                            'delete' => function ($url, $model) {
                                $dh = new DataHelper();
                                $url = Url::to(['data-request/customdelete','id'=>$model->id],true);
                                $link  = $dh->getModalButton($model, "data-request/customdelete", "Project", 'glyphicon glyphicon-remove','',$url);
                                return "&nbsp;".$link;
                            }
                        ], 
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
