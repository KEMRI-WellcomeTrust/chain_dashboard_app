<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\DataRequest */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Data Requests', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="data-request-view">

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'project_id',
            'user_id',
            'data_crfs:html',
            'data_variables:html',
            'data_sites',
            'date_from',
            'date_to',
            'other_info:html',
            'received_date',
            'reviewed_by',
            'approved_by',
            'approved_date',
            'status',
            'status_comments:html',
            'feedback:html',
        ],
    ]) ?>

</div>
